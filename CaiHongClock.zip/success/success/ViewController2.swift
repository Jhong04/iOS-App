//
//  ViewController2.swift
//  success
//
//  Created by Mac on 2024/1/10.
//  Copyright © 2024年 Mac. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    @IBOutlet weak var value: UITextField!
    @IBOutlet weak var slider: UISlider!
    override func viewDidLoad() {
        super.viewDidLoad()
        slider.addTarget(self,action:#selector(sliderValueChange(_:)),for:.valueChanged)

        // Do any additional setup after loading the view.
    }
    
    @objc func sliderValueChange(_ sender:UISlider){
        let t=sender.value
        AppData.count=Int(t)*60
        value.text=String(Int(t))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
