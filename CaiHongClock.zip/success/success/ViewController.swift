//
//  ViewController.swift
//  success
//
//  Created by Mac on 2024/1/9.
//  Copyright © 2024年 Mac. All rights reserved.
//

import UIKit

struct AppData{
    static var count:Int=10000; 
}

class ViewController: UIViewController {
    
    @IBOutlet weak var count: UITextField!
    var timer:Timer?
    @objc func refresh(){
        var calendar:Calendar=Calendar.current;
        var now=Date();
        var h=calendar.component(.hour, from: now);
        var m=calendar.component(.minute, from: now);
        var s=calendar.component(.second, from: now);
        hour.text=String(h);
        minute.text=String(m);
        second.text=String(s);
        if AppData.count != 0{
            count.text=String(AppData.count)
            AppData.count=AppData.count-1;
        }

    }
    
    

    @IBOutlet weak var click: UIButton!

    @IBOutlet weak var hour: UITextField!
    
    
    @IBOutlet weak var minute: UITextField!
    
    
    @IBOutlet weak var second: UITextField!
    
    @IBAction func ExitToHere(sender: UIStoryboardSegue){
        // nothing here
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        timer=Timer.scheduledTimer(timeInterval:1.0,target:self,selector:#selector(refresh),userInfo:nil,repeats:true)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
