//
//  ViewController1.swift
//  success
//
//  Created by Mac on 2024/1/9.
//  Copyright © 2024年 Mac. All rights reserved.
//
var arr:[String]=[];
import UIKit

class ViewController1: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        show()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var tf: UITextField!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func show(){
        for(index,item)in arr.enumerated(){
            let label=UILabel(frame: CGRect(x:50,y:100+index*30,width:300,height:30))
            label.text=item;
            label.font=UIFont.systemFont(ofSize:20)
            label.textColor=UIColor.red
            view.addSubview(label);
        }
    }
    
    @IBAction func del(_ sender: Any) {
        arr.removeAll()
        show()
    }

    @IBAction func add(_ sender: Any) {
        if let text=tf.text{
            if !text.isEmpty{
                arr.append(text)
                tf.text=""
            }
        }
        show()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
